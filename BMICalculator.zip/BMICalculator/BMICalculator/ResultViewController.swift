//
//  ResultViewController.swift
//  BMICalculator
//
//  Created by Panuganti,Sirisha on 11/2/23.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var resultWeightOL: UILabel!
    
    @IBOutlet weak var resultHeightOL: UILabel!
    
    
    @IBOutlet weak var BMI: UILabel!
    
    
    @IBOutlet weak var imageOL: UIImageView!
    
    var height = 0.0
    var weight = 0.0
    var bmi = 0.0
    var image = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        resultWeightOL.text! += String(height)
        resultHeightOL.text! += String(weight)
        BMI.text! += String(bmi)
        imageOL.image = UIImage(named: image)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
