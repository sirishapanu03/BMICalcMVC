//
//  ViewController.swift
//  BMICalculator
//
//  Created by Panuganti,Sirisha on 11/2/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var weightOL: UITextField!
    
    
    @IBOutlet weak var heightOL: UITextField!
    
    var bmi = 0.0
    var imageName = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func calcBMIClicked(_ sender: Any) {
        
        var weight = Double(weightOL.text!) ?? 0.0
        var height = Double(heightOL.text!) ?? 0.0
        
        bmi = (weight / (height * height)) * 703
        
        if(bmi <= 18.4){
            imageName = "under"
            
        }else if(bmi >= 18.5 && bmi <= 24.9){
            imageName = "normal"
        }else if(bmi >= 25.0 && bmi <= 39.9){
            imageName = "over"
        }
        else if(bmi >= 40.0){
            imageName = "obese"
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition == "resultSegue"){
            var destination = segue.destination as! ResultViewController
            destination.weight = Double(weightOL.text!) ?? 0.0
            destination.height = Double(heightOL.text!) ?? 0.0
            destination.bmi = bmi
            destination.image = imageName
            
        }
    }
    
}

